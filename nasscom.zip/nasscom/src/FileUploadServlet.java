import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.oreilly.servlet.MultipartRequest;

@MultipartConfig(fileSizeThreshold=1024*1024*10,    // 10 MB 
maxFileSize=1024*1024*50,          // 50 MB
maxRequestSize=1024*1024*100)      // 100 MB

public class FileUploadServlet extends HttpServlet {
	private static final long serialVersionUID = 205242440643911308L;
	 private static final String UPLOAD_DIR = "uploads";
	   
public void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
	String fileName = null;		
	 MultipartRequest m=new MultipartRequest(request,"C:\\MyEclipse Professional\\nasscom\\WebRoot\\imageupload");
	 
	 
	        //String end[]={"xls"};
	        for (Part part : request.getParts())
	        {
	        	//System.out.println("hello1");
	        	fileName = getFileName(part);
	            System.out.println(fileName);
	 	            
	        }
	        //System.out.println(m.getFile(fname));

	 //       System.out.println(fileName);
	        /*String file="C:\\MyEclipse Professional\\nasscom\\WebRoot\\imageupload"+fileName;
	        try{
	        	Connection con;
	        		String dbUrl = "jdbc:oracle:thin:@localhost:1521:xe";
	        	            Class.forName("oracle.jdbc.driver.OracleDriver").newInstance();
	        	            con=DriverManager.getConnection(dbUrl,"system","root");
	        	  PreparedStatement ps=con.prepareStatement("insert into VEHICLE_DETAILS values(?)");  
	        		System.out.println("hello");
	        				ps.setString(31, file);
	        	        		        		
	        	  
	        	  }catch(Exception e)
	        	  {
	        	  
	        	  }*/
    		  
	        }
	            private String getFileName(Part part) {
	        String contentDisp = part.getHeader("content-disposition");
	        System.out.println("content-disposition header= "+contentDisp);
	        String[] tokens = contentDisp.split(";");
	        for (String token : tokens) {
	            if (token.trim().startsWith("filename")) {
	                return token.substring(token.indexOf("=") + 2, token.length()-1);
	            }
	        }
	        return "";
	    }
	}


	


